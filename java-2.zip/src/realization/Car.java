package realization;
	
public interface Car {
	void run();
}
