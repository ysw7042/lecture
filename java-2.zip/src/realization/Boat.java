package realization;

public interface Boat {
	void navigate();
}
